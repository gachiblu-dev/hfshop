# hfshop

Proyecto React + Vite + TailwindCSS para **HF Products** (hfshop).

## Requisitos
- Node.js (ya instalado)
- npm

## Pasos para ejecutar localmente

1. Instala dependencias:
```bash
npm install
```

2. Ejecuta en modo desarrollo:
```bash
npm run dev
```

3. Construye para producción:
```bash
npm run build
```

## Subir a Netlify (resumen)
1. Sube el repositorio a GitHub.
2. En Netlify, elige "New site from Git" y conecta tu repo.
3. Configura build command: `npm run build` y publish directory: `dist`.
4. Despliega. Netlify hará deploy automático en cada push.

## Notas importantes
- El logo está en `public/logo.png`.
- Reemplaza las imágenes placeholder en `src/assets/` por tus fotos reales.
- El sitio usa un tema oscuro (negro/gris) y carga una animación de bienvenida con el logo.
