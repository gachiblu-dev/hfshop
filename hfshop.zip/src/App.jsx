import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const PRODUCTS = [
  { id:1, category:'Ropa', name:'Camiseta Urban Basic', price:'$45.000', image:'/src/assets/placeholder1.jpg' },
  { id:2, category:'Gorras', name:'Gorra Snapback HF', price:'$30.000', image:'/src/assets/placeholder2.jpg' },
  { id:3, category:'Zapatos', name:'Zapatilla Street Classic', price:'$120.000', image:'/src/assets/placeholder3.jpg' },
];

export default function App(){
  const whatsappNumber = '573045609415';
  const instagramHandle = '@hfproducts';
  const [showWelcome, setShowWelcome] = useState(true);

  useEffect(()=>{
    const t = setTimeout(()=> setShowWelcome(false), 2200);
    return ()=> clearTimeout(t);
  },[]);

  const waMessage = encodeURIComponent('Hola! Quiero hacer un pedido: (indica producto y talla).');

  return (
    <div className="min-h-screen flex flex-col">
      <AnimatePresence>
      {showWelcome && (
        <motion.div className="fixed inset-0 z-50 flex items-center justify-center bg-black"
          initial={{ opacity: 1 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, transition:{duration:0.6} }}
        >
          <motion.div initial={{ scale:0.8 }} animate={{ scale:1 }} transition={{ duration:0.6 }}>
            <img src="/logo.png" alt="HF Products" className="w-48 h-48 mx-auto object-contain" />
            <h2 className="text-center text-2xl font-semibold mt-4">Bienvenido a HF Products</h2>
          </motion.div>
        </motion.div>
      )}
      </AnimatePresence>

      <header className="bg-transparent py-5">
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/logo.png" alt="HF" className="w-12 h-12 object-contain"/>
            <div>
              <h1 className="text-lg font-bold">HF Products</h1>
              <p className="text-sm text-gray-400">Ropa · Gorras · Zapatos</p>
            </div>
          </div>

          <nav className="hidden md:flex gap-6 items-center text-sm">
            <a href="#productos" className="hover:underline">Productos</a>
            <a href="#publicidad" className="hover:underline">Publicidad</a>
            <a href="#contacto" className="hover:underline">Contacto</a>
            <a href={`https://wa.me/${whatsappNumber}?text=${waMessage}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 px-4 py-2 border rounded-md text-sm">
              Pedir (WhatsApp)
            </a>
          </nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-8 flex-1">
        <section className="grid md:grid-cols-2 gap-8 items-center py-8">
          <div>
            <h2 className="text-4xl font-extrabold mb-4">Estilo, actitud y calidad</h2>
            <p className="text-gray-400 mb-6">Descubre nuestra selección de ropa, gorras y zapatillas pensadas para el estilo urbano de todos los días.</p>
            <div className="flex gap-3">
              <a href="#productos" className="px-6 py-3 bg-white text-black rounded-md shadow">Ver productos</a>
              <a href={`https://wa.me/${whatsappNumber}?text=${waMessage}`} target="_blank" rel="noreferrer" className="px-6 py-3 border rounded-md">Pedir por WhatsApp</a>
            </div>
          </div>

          <div className="rounded-xl overflow-hidden bg-gradient-to-br from-gray-900 to-black p-6">
            <img src="/src/assets/hero-placeholder.jpg" alt="Banner" className="w-full h-72 object-cover rounded-md" />
          </div>
        </section>

        <section id="productos" className="mt-10">
          <h3 className="text-2xl font-bold mb-6">Productos</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {PRODUCTS.map(p => (
              <article key={p.id} className="bg-gradient-to-b from-gray-900 to-black rounded-lg overflow-hidden shadow-sm border border-gray-800">
                <img src={p.image} alt={p.name} className="w-full h-56 object-cover"/>
                <div className="p-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-semibold">{p.name}</h4>
                    <span className="text-gray-400 text-sm">{p.price}</span>
                  </div>
                  <p className="text-sm text-gray-500 mt-2">Categoría: {p.category}</p>
                  <div className="mt-4 flex gap-2">
                    <a href={`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(`Hola, quiero el producto: ${p.name} - ¿tienen tallas disponibles?`)}`} target="_blank" rel="noreferrer" className="flex-1 text-center px-3 py-2 rounded-md border">Pedir por WhatsApp</a>
                    <a href="#" onClick={(e)=>{e.preventDefault(); window.open(`https://instagram.com/${instagramHandle.replace('@','')}`,'_blank')}} className="px-3 py-2 rounded-md bg-white text-black">Ver en Instagram</a>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section id="publicidad" className="mt-12 bg-gradient-to-b from-gray-900 to-black rounded-lg p-6 border border-gray-800">
          <h3 className="text-2xl font-bold mb-2">Publicidad y colaboraciones</h3>
          <p className="text-gray-400 mb-4">¿Tienes una marca o servicio y quieres aparecer en HF Products? Ofrecemos espacios publicitarios en la página, publicaciones patrocinadas en Instagram y colaboraciones de producto.</p>
          <ul className="list-disc pl-5 text-gray-400 mb-4">
            <li>Banner en la página principal</li>
            <li>Publicación patrocinada en redes</li>
            <li>Promociones y descuentos por colaboración</li>
          </ul>
          <a href={`https://wa.me/${whatsappNumber}?text=${encodeURIComponent("Hola, estoy interesado en publicidad/colaboración. ¿Podemos hablar?")}`} target="_blank" rel="noreferrer" className="inline-block px-5 py-3 bg-white text-black rounded-md">Contactar por WhatsApp</a>
        </section>

        <section id="contacto" className="mt-12 p-6 rounded-lg">
          <h3 className="text-2xl font-bold mb-4">Contacto</h3>
          <div className="grid md:grid-cols-2 gap-6 items-center">
            <div className="bg-gradient-to-b from-gray-900 to-black rounded-lg p-6 border border-gray-800">
              <p className="mb-3">WhatsApp: <strong>+57 304 560 9415</strong></p>
              <p className="mb-3">Email: <strong>fernandofarietta@hotmail.com</strong></p>
              <p className="mb-3">Instagram: <strong>@hfproducts</strong> (actualízalo cuando lo tengas)</p>
              <p className="text-gray-400">También puedes escribirnos directamente para consultas de producto, tallas, envíos y publicidad.</p>

              <div className="mt-4 flex gap-3">
                <a href={`https://wa.me/${whatsappNumber}?text=${waMessage}`} target="_blank" rel="noreferrer" className="px-4 py-2 bg-green-600 text-white rounded-md">WhatsApp</a>
                <a href={`https://instagram.com/${instagramHandle.replace('@','')}`} target="_blank" rel="noreferrer" className="px-4 py-2 border rounded-md">Instagram</a>
              </div>
            </div>

            <form className="bg-gradient-to-b from-gray-900 to-black rounded-lg p-6 border border-gray-800">
              <label className="block mb-2 text-sm">Tu nombre</label>
              <input className="w-full mb-3 px-3 py-2 border rounded bg-transparent" placeholder="Tu nombre" />

              <label className="block mb-2 text-sm">Tu correo (opcional)</label>
              <input className="w-full mb-3 px-3 py-2 border rounded bg-transparent" placeholder="correo@ejemplo.com" />

              <label className="block mb-2 text-sm">Mensaje</label>
              <textarea className="w-full mb-3 px-3 py-2 border rounded bg-transparent" rows={4} placeholder="Escribe tu consulta..."></textarea>

              <button type="button" onClick={()=>alert('Para enviar mensajes, usa el WhatsApp: +57 304 560 9415')} className="px-4 py-2 bg-white text-black rounded-md">Enviar mensaje</button>
            </form>
          </div>
        </section>

      </main>

      <footer className="text-center text-sm text-gray-500 py-6">© 2025 HF Products</footer>
    </div>
  );
}
